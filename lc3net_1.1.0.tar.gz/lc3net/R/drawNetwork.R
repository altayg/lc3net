drawNetwork <- function(annotation,indice,MI,network)
{
  x=matrix();
  genesF=toupper(annotation[as.matrix(indice[,1]),2]);
  genesS=toupper(annotation[as.matrix(indice[,2]),2]);
  genesDetail=cbind(as.matrix(genesF),as.matrix(genesS));
  for(i in 1:nrow(indice)) {x[i]=MI[indice[i,1],indice[i,2]];}
  
  genesDetail=cbind(genesDetail[,1:2],x);
  
  colnames(genesDetail)=c("First Gene","Second Gene", "MI");  # ASSIGN COLUMN NAMES
  
  genesDetail=genesDetail[order(genesDetail[,"MI"],decreasing=TRUE),]; # SORT ACCORDING TO MI VALUES
  
  idx <- !duplicated(t(apply(genesDetail[,1:2], 1, sort))); # ELEMINATE REPEATED AND LOWER MI VALUES
  
  genesDetail=genesDetail[idx,]; # same with lc3net 
  
  
  #### DRAWING PART ############################
  if(network==TRUE)
  {
    ge <- graph.data.frame(genesDetail[,1:2], directed = FALSE);
    ge <- set.edge.attribute(ge, "weight", value=as.numeric(genesDetail[,3]));
    
    E(ge)$edgeWidth <- as.numeric(genesDetail[,3])*300;
    
    ge <- simplify(ge);
    
    
    rdp <- RedPort('MyPort');
    calld(rdp);
    addGraph( rdp, ge, layout.random(ge) );
    summary(ge);
    
  }
  
  genesDetail
  
  
}