lc3net <- function (dataset,annotation,mim=NULL, cop=TRUE, alphaRN=0.001,rankRN=40,methodRN="rank",alphaC3NET=0.005,rankC3NET=1,methodC3NET="alpha",itnum=1, ppi=TRUE,pathwayppi=TRUE,externalData=NULL,network=FALSE)
{
  
  netRN <- NULL;
  netC3 <- NULL;

  k=which(annotation[,2]!="");
  annotation=annotation[k,];
  dataset=dataset[k,];
      
  
  if(is.null(mim)==TRUE)
  {
    
    if(cop==TRUE){
      dataset <- copula(dataset);
    }
    
    mim <- makemim(dataset);
    mim2=mim;
  }
  
  ## C3NET PART #### 
  if(methodC3NET=="alpha")
  {
    genes=annotation[,2];
    netC3=mim; 
    
    ngene <- length(genes)
    
    for(i in 1:ngene){
      indx <- which(genes==genes[i])
      if(length(indx)>1){netC3[i, indx] <- 0} 
    } 
    
    
    tempV=as.vector(netC3);
    temp<-sort(tempV);
    L <- length(temp);
    order <- ceiling((1-alphaC3NET)*L);
    thresholdValueC3=temp[order];
    netC3[netC3 < thresholdValueC3] <-0 ;
    netC3[upper.tri(netC3)]=0
    netC3=as.matrix(netC3);
    netC3 <- c3(netC3);
   
  }
  
  else if(methodC3NET=="rank")
  {
    
    genes=annotation[,2];
    netC3=mim;

        
    ngene <- length(genes)
    
    for(i in 1:ngene){
      indx <- which(genes==genes[i])
      if(length(indx)>1){netC3[i, indx] <- 0} 
    } 
    
    
    temp=as.vector(netC3);
    L <- length(temp);
    
    const=nrow(dataset);
    rankC3NET=rankC3NET*const;
    
    k=nrow(dataset);
    max_int=k*k;
    if(rankC3NET> max_int)
    {
      rankC3NET= max_int;
    }
    thresholdValueC3NET<-sort(mim,decreasing=TRUE)[rankC3NET];
    netC3[netC3 < thresholdValueC3NET] <-0 ;
    netC3[upper.tri(netC3)]=0
    netC3=as.matrix(netC3);
    netC3 <- c3(netC3);
    rankC3NET=((rankC3NET)/L);
    print(rankC3NET)
    
  }
  
  else 
  {
    printf("Choose correct parameter");
  }
    
  if(itnum>1)
  {
    c3net=sigtestp( dataset, alphaC3NET, itnum);
    netc3 <- c3(c3net$Inew) ;
    
  }
   
  
  if(methodRN=="alpha")
  {
    
    netRN=mim;
    tempV=as.vector(netRN);
    temp<-sort(tempV);
    L <- length(temp);
    order <- ceiling((1-alphaRN)*L);
    thresholdValueRN=temp[order];
    netRN[netRN < thresholdValueRN] <-0 ;
    
  }
  
  
  else if(methodRN=="rank")
  {
    
    netRN=mim;
    
    const=nrow(dataset);
    rankRN=rankRN*const;
    
    temp=as.vector(netRN);
    L <- length(temp);
    
    k=nrow(dataset);
    max_int=k*k;
    if(rankRN> max_int)
    {
      rankRN= max_int;
    }
    thresholdValueRN<-sort(mim,decreasing=TRUE)[rankRN];
    netRN[netRN < thresholdValueRN] <-0 ;
    
    rankRN=(rankRN/L);    

  }


  else 
  {
    printf("Choose correct parameter");
  }
  
  if(itnum>1)
  {
       res=sigtestp( dataset, alphaRN, itnum);
       netRN=res$Inew;
  
  }
  
  tempF=convert2Binary(netC3,annotation); 
  binaryC3NET= tempF$interactions;
  c3netInt=tempF$indices;

  
  tempF=convert2Binary(netRN,annotation);
  binaryRN=tempF$interactions;
  rnInt=tempF$indices;


  if(ppi==TRUE & pathwayppi==FALSE)
  {
    ppiData= ganet.combine () ;
    #rm(bind);rm(bind_translation);rm(biogrid);rm(corum);rm(dip);rm(hprd);rm(intact);rm(mint);rm(innatedb);rm(transcompel);rm(transfac);rm(transfac_pro);rm(mpi);
  }
  
  else if (ppi==FALSE & pathwayppi==TRUE)
  {
    ppiData= ganet.combine (BIOGRID=0,CORUM=0,DIP=0,HPRD=0,
                            INNATEDB=0,INTACT=0,MINT=0,MPI=0,NAT=1,REACT=1)
    #rm(UniHI);rm(cell);rm(imid);rm(nat);rm(reactome);
  }
  
  else if(ppi==TRUE & pathwayppi==TRUE)
  {
    ppiData= ganet.combine (BIOGRID=1,CORUM=1,DIP=1,HPRD=1,
                            INNATEDB=1,INTACT=1,MINT=1,MPI=1,NAT=1,REACT=1) ;
    #rm(bind);rm(bind_translation);rm(biogrid);rm(corum);rm(dip);rm(hprd);rm(intact);rm(mint);rm(innatedb);rm(transcompel);rm(transfac);rm(transfac_pro);rm(mpi);rm(UniHI);rm(cell);rm(imid);rm(nat);rm(reactome);
  }
  
  else if( is.null(externalData)==FALSE)
  {
     ppiData= externalData;
  }
  else if(ppi==FALSE & pathwayppi==FALSE & externalData==FALSE)
  {
    print("Select validation dataset");
  }
  
  ppiData=ganet.UniqNetSimp(ppiData);
  ValidatedLiterature <-ganet.ComLinks(netlist=as.matrix(binaryRN), netdata=as.matrix(ppiData)); 
  c3netValidated <- ganet.ComLinks(netlist=as.matrix(binaryC3NET), netdata=as.matrix(ppiData));


  enrichedInteractionSet= rbind(ValidatedLiterature[,1:2],binaryC3NET[,1:2]);

  tempValidatedLiterature=ValidatedLiterature[,3]; 
  

  class(tempValidatedLiterature)="numeric";
  #rnInt= rnInt[as.matrix(tempValidatedLiterature),];
  tempIndc=as.matrix(tempValidatedLiterature);
  rnInt= rnInt[tempIndc[,1],];
  
  
   enrichedInteractionSet= ganet.UniqNetSimp(enrichedInteractionSet);  # enrichedInteractionSet= getUniqueInteractions(enrichedInteractionSet,1,2);  
   ValidatedLiterature=ganet.UniqNetSimp(ValidatedLiterature);  ## enrichedInteractionSet= getUniqueInteractions(enrichedInteractionSet,1,2);  
   c3netValidated=ganet.UniqNetSimp(c3netValidated);  ## enrichedInteractionSet= getUniqueInteractions(enrichedInteractionSet,1,2);  
   binaryC3NET=ganet.UniqNetSimp(binaryC3NET);
  
  
   
  finalValidation <-ganet.ComLinks(netlist=as.matrix(enrichedInteractionSet), netdata=as.matrix(ppiData)); # validated binary interactions


################################ DRAWING PART ######################3

  
  wholeInd=rbind(rnInt,c3netInt)
  wholeInd=ganet.UniqNetSimp(wholeInd)
  class(wholeInd)="numeric";


  drawValues= mim2[wholeInd[,1],wholeInd[,2]]; # MI VALUES

  drawInfo=matrix(data=NA);


  drawInfo=drawNetwork(annotation,wholeInd,mim2,network);

  
###################################################################################

  res <- new.env() ;
  assign("lc3net", enrichedInteractionSet, envir=res);
  assign("validated", ValidatedLiterature, envir=res); 
  assign("relnet", binaryRN, envir=res);
  assign("c3net", binaryC3NET, envir=res);
  assign("vc3net", c3netValidated, envir=res);
  assign("finalvalidation", finalValidation, envir=res);
  assign("ppi", ppiData, envir=res);
  assign("indice", wholeInd, envir=res);
  assign("mi",mim2,envir=res);
  assign("drawInfo",drawInfo,envir=res);


#   assign("drawValues",drawValues,envir=res);
#   assign("rankrn",rankRN,envir=res);
#   assign("rankc3",rankC3NET,envir=res);
#   assign("drawInfo",drawInfo,envir=res);

  
  evaluatePerformance(res,annotation);
  
  
  res
  
}