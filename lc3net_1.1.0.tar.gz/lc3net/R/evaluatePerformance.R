evaluatePerformance <- function(res,anno)
{

  k=as.vector(res$lc3net);
  k=unique(k);
  tu=length(k);
  

  temp=as.vector((anno[,2]));
  temp=unique(temp);
  
  
  tempL=length(temp);
  nUniverse <- tempL*(tempL- 1)/2;
  nUniverse <- round(nUniverse/2);
  
  
#   wholePoss=expand.grid(temp,temp);
#   temp=ganet.UniqNetSimp(wholePoss);

  
  Validated <-ganet.ComLinks(netlist=as.matrix(res$lc3net), netdata=as.matrix(res$ppi));

  
  #nFocusedSet <-nrow(ganet.ComLinks(netlist=as.matrix(res$ppi), netdata=as.matrix(temp)));
  
  nFocusedSet <- length( intersect(which(res$ppi[,1] %in% temp),which(res$ppi[,2]%in% temp)) ); 
  
 
  nOverlap=nrow(Validated);nPredicted=nrow(res$lc3net); nFocusedSet=nFocusedSet;nUniverse=nUniverse;
 
  
    
  fin <- ganet.FEtest(nOverlap=nrow(Validated),nPredicted=nrow(res$lc3net), nFocusedSet=nFocusedSet,nUniverse=nUniverse)


  cat("Number of inferred LC3NET interactions: ", nrow(res$lc3net),"\n") 
  cat("Number of inferred C3NET interactions: ",nrow(res$c3net),"\n")  
  cat("Number of inferred Relevance Network interactions: ",nrow(res$relnet),"\n") 
  cat("Number of inferred validated Relevance Network interactions: ",nrow(res$validated),"\n") 
  cat("Number of inferred validated C3NET interactions: ",nrow(res$vc3net),"\n") 
  cat("Number of inferred validated LC3NET interactions: ",nrow(res$finalvalidation),"\n") 
  #cat("Alpha value of RN: ", res$rankrn, "\n")  
  cat("p-value of inferred LC3NET interactios: ",fin$stats$p.value,"\n")  
  cat("Precision  of inferred LC3NET interactios: ",fin$precision,"\n")  
  
  res
  
  
}