convert2Binary <- function(net,anno)
{

    miValues=matrix();
    indices=which(net>0,arr.ind=TRUE);
    indices=ganet.UniqNetSimp(indices);
    class(indices)="numeric";
    anno[,2]=toupper(anno[,2]);
    rownamesAll=as.matrix(anno[,2]);
    firstColumn=as.matrix(rownamesAll[indices[,1],1]);
    secondColumn=as.matrix(rownamesAll[indices[,2],1]);
    interactions=cbind(firstColumn,secondColumn);
    interactions[,1]=toupper(interactions[,1]);
    interactions[,2]=toupper(interactions[,2]);
    
    
    result <- new.env() ;
    assign("interactions", interactions, envir=result);
    assign("indices", indices, envir=result);
    result
}